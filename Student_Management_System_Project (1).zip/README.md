# Student Management System

## Introduction
The Student Management System is a beginner-level Python project for storing and managing student records. It allows the user to add, view, search, and delete student information.

## Features
- Add student records
- View all students
- Search by student ID
- Delete student records
- Store data in a JSON file
- Basic input validation
- Automated testing

## Python Concepts Used
Variables, strings, lists, dictionaries, conditional statements, loops, functions, modules, file handling, JSON, exception handling, and assertions.

## Requirements
- Python 3 or above
- No external libraries

## How to Run
1. Open the project folder.
2. Run `main.py`.
3. Follow the menu instructions.

Command line:
```text
python main.py
```

## Testing
Run:
```text
python test_project.py
```

## Project Files
- `main.py` - main menu and program flow
- `student_data.py` - student record storage
- `student_display.py` - output display
- `student_utils.py` - input and validation
- `student_words.py` - course list utility
- `student_reports.py` - summary utility
- `test_project.py` - automated tests
- `README.md` - documentation
- `statement.md` - project statement

## Author
Student Name: __________________
