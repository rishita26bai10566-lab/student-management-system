# Project Statement

## Problem Statement
Educational institutions manage information about many students. Maintaining records manually can make searching, updating, and organizing student information difficult. This project provides a simple Python-based system for managing basic student records.

## Scope
The system focuses on basic student record management. It can add, view, search, and delete student records and stores the information in a JSON file.

## Target Users
- Students learning Python
- Teachers demonstrating basic record management
- Small educational projects requiring simple student records

## High-Level Features
1. Add student
2. View students
3. Search student
4. Delete student
5. Store records in JSON
6. Validate basic input
7. Test core operations
